const Data = [];
function InitializeData() {
    for(let i = 0; i < 100; i++) {
        const obj = {
            'id' : (i+1),
            'firstName' : 'fname' + (i+1),        
            'lastName' : 'lname' + (i+1),        
            'username' : 'uname' + (i+1),        
            'age' : i,        
            'address' : 'street' + (i+1),        
            'city' : 'city' + (i+1),        
            'country' : 'country' + (i+1),        
        }
        Data.push(obj);
    }
}
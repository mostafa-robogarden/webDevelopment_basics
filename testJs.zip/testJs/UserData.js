class UserData {
    constructor(username, email, password, age) {
        this.username = username;
        this.email = email;
        this.password = password;
        this.age = age;
    }
}
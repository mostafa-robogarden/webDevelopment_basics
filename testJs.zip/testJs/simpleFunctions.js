function Compare(firstNumber, secondNumber) {
    if(firstNumber > secondNumber)
        return firstNumber;
    else
        return secondNumber;
    //return a > b ? a : b;
}
function GetSum(arr) {
    let sum = 0;
    for(element in arr) {
        sum += arr[element];
    }
    return sum;
}
function GetMax(arr) {
    let max = 0;
    for(let element of arr) {
        if(element > max)
            max = element;
    }
    return max;
}
function IsEven(number) {
    if(number % 2 === 0)
        return true;
    else 
        return false;
}
function Search(arr, element) {
    for(let i = 0; i < arr.length; i++) {
        if(arr[i] === element)
            return i;
    }
    return -1;
}
const Swap = (first, second) => {
    const third = first;
    first = second;
    second = third
    console.log(first, second);
}
function Factorial(number) {
    if(number === 1)
        return 1;
    return Factorial(number - 1) * number;
}
function Fibonacci(number) {
    if(number <= 1)
        return number;
    return Fibonacci(number - 1) + Fibonacci(number - 2);
}
function CountPattern(arr, pattern) {
    let count = 0;
    for(element in arr) {
        if(arr[element] === pattern)
            count += 1;
    }
    return count;
}
function Sort(arr) {
    if(arr === null || arr === undefined || arr.length === 0)
        return [];
    for(let i = 0 ; i < arr.length; i++) {
        for(let j = i; j < arr.length; j++) {
            if(arr[j] < arr[i]) {
                const temp = arr[j];
                arr[j] = arr[i];
                arr[i] = temp;
            }
        }
    }
    return arr;
}
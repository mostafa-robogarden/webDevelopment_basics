class Permission {
    static loggedIn = false;
    static Users = [];
   }